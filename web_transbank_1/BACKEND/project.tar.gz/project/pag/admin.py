from django.contrib import admin
from .models import *

# Register your models here.

admin.site.register(Pagina)
admin.site.register(UserPagina)
admin.site.register(AdminPagina)
admin.site.register(CodeVerificationUser)
